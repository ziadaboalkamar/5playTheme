<?php
/**
 * @package  DTAppsScrapper
 */
namespace Inc\Base;

class UnInstall {
    function __construct() {
    }
}