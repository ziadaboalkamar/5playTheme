<?php
 # Silence is golden.

