<?php
/*-----------------------------------------------------------------------------------*/
/*  EXTHEM.ES
/*  PREMIUM WORDRESS THEMES
/*
/*  STOP DON'T TRY EDIT
/*  IF YOU DON'T KNOW PHP
/*  AS ERRORS IN YOUR THEMES ARE NOT THE RESPONSIBILITY OF THE DEVELOPERS
/*
/*
/*  @EXTHEM.ES
/*  Follow Social Media Exthem.es
/*  Youtube : https://www.youtube.com/channel/UCpcZNXk6ySLtwRSBN6fVyLA
/*  Facebook : https://www.facebook.com/groups/exthem.es
/*  Twitter : https://twitter.com/ExThemes
/*  Instagram : https://www.instagram.com/exthemescom/
/*	More Premium Themes Visit Now On https://exthem.es/
/*
/*-----------------------------------------------------------------------------------*/ 
require EX_THEMES_DIR.'/libs/core/inits.php';
require EX_THEMES_DIR.'/libs/core/addscripts.php';
require EX_THEMES_DIR.'/libs/core/breadcrums.php';
require EX_THEMES_DIR.'/libs/tgm.php';
require EX_THEMES_DIR.'/libs/core/comments.php';
require EX_THEMES_DIR.'/libs/core/cores.php';
require EX_THEMES_DIR.'/libs/core/ads.php';
require EX_THEMES_DIR.'/libs/core/adm.php';
require EX_THEMES_DIR.'/libs/core/extra.php';
require EX_THEMES_DIR.'/libs/core/cpt.php';
require EX_THEMES_DIR.'/libs/core/warning.php';
require EX_THEMES_DIR.'/libs/core/widget.php';
require EX_THEMES_DIR.'/libs/core/install_page.php';
require EX_THEMES_DIR.'/libs/core/gallery.php';
require EX_THEMES_DIR.'/libs/register_plugin.php';
require EX_THEMES_DIR.'/libs/core/background.php';
require EX_THEMES_DIR.'/libs/import-demo.php'; 
require EX_THEMES_DIR.'/wp-report-post/wp-report-post.php';
require EX_THEMES_DIR.'/like-dislike/like-dislike.php';
require EX_THEMES_DIR.'/posts-like-dislike/posts-like-dislike.php'; 
require EX_THEMES_DIR.'/libs/core/login.php';
/* 
if (!is_customize_preview()  && is_admin() ) {
require_once (EX_THEMES_DIR. '/libs/merlin/vendor/autoload.php' );
require_once (EX_THEMES_DIR. '/libs/merlin/class-merlin.php' );
require_once (EX_THEMES_DIR. '/libs/merlin/merlin-config.php' );
require_once (EX_THEMES_DIR. '/libs/merlin/marlin-import.php' );
}
 */
ini_set('display_errors', ERRORS);